
## 💻 Hardware Issues

- Blue Screen of Death (BSOD)
- Unrecognized devices (USB, printers, etc.)
- Outdated or incompatible drivers
- Hard drive or SSD errors (SMART warnings, bad sectors)
- Graphics or sound card problems
